#!/usr/bin/env perl
use strict;
use warnings;
use File::Spec;

my $in_dir  = $ARGV[0] or die "Usage: $0 <inputs_dir> <output_dir>\n";
my $out_dir = $ARGV[1] or die "Usage: $0 <inputs_dir> <output_dir>\n";

my $pre_file  = File::Spec->catfile($in_dir, "reports", "pre_fix", "clock_gating.rpt");
my $post_file = File::Spec->catfile($in_dir, "reports", "post_fix", "clock_gating.rpt");
my $plan_file = File::Spec->catfile($out_dir, "fix_plan.txt");

die "Error: Missing $pre_file\n" unless (-e $pre_file && -r $pre_file);
die "Error: Missing $post_file\n" unless (-e $post_file && -r $post_file);
die "Error: Missing $plan_file. Run level4.pl first!\n" unless (-e $plan_file && -r $plan_file);

# Generic parser and metrics analyzer
sub analyze_dataset {
    my ($file) = @_;
    my (%cfg, %gates, %ungated);

    open(my $fh, '<', $file) or die "Cannot read $file: $!\n";
    while (my $line = <$fh>) {
        chomp $line;
        next if $line =~ /^\s*(#|$)/;
        $line =~ s/^\s+//;
        $line =~ s/\s+$//;

        if ($line =~ /TOTAL_CYCLES\s+(\d+)/)                 { $cfg{TOTAL_CYCLES} = $1; }
        if ($line =~ /MIN_GATING_EFFICIENCY\s+([\d.]+)/)     { $cfg{MIN_GATING_EFFICIENCY} = $1; }
        if ($line =~ /E_CLK_PJ_PER_REG_CYCLE\s+([\d.]+)/)    { $cfg{E_CLK_PJ_PER_REG_CYCLE} = $1; }
        if ($line =~ /MIN_REGS_FOR_GATING\s+(\d+)/)          { $cfg{MIN_REGS_FOR_GATING} = $1; }
        if ($line =~ /MAX_ENABLE_TOGGLE_PERCENT\s+([\d.]+)/) { $cfg{MAX_ENABLE_TOGGLE_PERCENT} = $1; }
        if ($line =~ /TARGET_SAVING_PERCENT\s+([\d.]+)/)     { $cfg{TARGET_SAVING_PERCENT} = $1; }

        if ($line =~ /^GATE\s+(\S+)\s+ENABLE\s+(\S+)\s+REGS\s+(\d+)\s+DISABLED_CYCLES\s+(\d+)\s+ENABLE_TOGGLES\s+(\d+)\s+MODULE\s+(\S+)/) {
            $gates{$1} = {
                id => $1, enable => $2, regs => $3 + 0,
                disabled_cycles => $4 + 0, enable_toggles => $5 + 0, module => $6
            } unless exists $gates{$1};
        }

        if ($line =~ /^UNGATED_GROUP\s+(\S+)\s+REGS\s+(\d+)\s+IDLE_CYCLES\s+(\d+)\s+MODULE\s+(\S+)/) {
            $ungated{$1} = {
                name => $1, regs => $2 + 0, idle_cycles => $3 + 0, module => $4
            } unless exists $ungated{$1};
        }
    }
    close($fh);

    my $tot_cyc  = $cfg{TOTAL_CYCLES} || 10000;
    my $min_eff  = $cfg{MIN_GATING_EFFICIENCY} || 60.0;
    my $e_clk    = $cfg{E_CLK_PJ_PER_REG_CYCLE} || 0.30;
    my $min_regs = $cfg{MIN_REGS_FOR_GATING} || 8;
    my $max_tog  = $cfg{MAX_ENABLE_TOGGLE_PERCENT} || 50.0;

    my $total_regs = 0;
    my $disabled_reg_cycles = 0;
    my $total_energy = 0.0;
    my %obj_energy;
    my %obj_eff;

    for my $id (keys %gates) {
        my $g = $gates{$id};
        my $active = $tot_cyc - $g->{disabled_cycles};
        my $e = $g->{regs} * $active * $e_clk;
        my $eff = ($g->{disabled_cycles} / $tot_cyc) * 100.0;
        $total_energy += $e;
        $total_regs += $g->{regs};
        $disabled_reg_cycles += ($g->{regs} * $g->{disabled_cycles});
        $obj_energy{$id} = $e;
        $obj_eff{$id} = $eff;
    }

    for my $name (keys %ungated) {
        my $u = $ungated{$name};
        my $e = $u->{regs} * $tot_cyc * $e_clk;
        my $eff = 0.0;
        $total_energy += $e;
        $total_regs += $u->{regs};
        $obj_energy{$name} = $e;
        $obj_eff{$name} = $eff;
    }

    my $overall_eff = ($total_regs > 0 && $tot_cyc > 0) ? ($disabled_reg_cycles / ($total_regs * $tot_cyc)) * 100.0 : 0.0;

    # Violations detection
    my @violations;
    my ($n_missing, $n_low_eff, $n_tog, $n_red) = (0, 0, 0, 0);

    for my $name (sort keys %ungated) {
        my $u = $ungated{$name};
        my $idle_pct = ($u->{idle_cycles} / $tot_cyc) * 100.0;
        if ($u->{regs} >= $min_regs && $idle_pct >= $min_eff) {
            my $rec = $u->{regs} * $u->{idle_cycles} * $e_clk;
            push @violations, {
                type => 'MISSING_GATE', object => $name, module => $u->{module},
                recoverable_pj => $rec, severity => 'CRITICAL'
            };
            $n_missing++;
        }
    }

    my $target_disabled = $tot_cyc * $min_eff / 100.0;
    for my $id (sort keys %gates) {
        my $g = $gates{$id};
        my $eff = ($g->{disabled_cycles} / $tot_cyc) * 100.0;
        my $tog = ($g->{enable_toggles} / $tot_cyc) * 100.0;

        if ($g->{regs} >= $min_regs && $eff < $min_eff) {
            my $rec = $g->{regs} * ($target_disabled - $g->{disabled_cycles}) * $e_clk;
            push @violations, {
                type => 'LOW_EFFICIENCY', object => $id, module => $g->{module},
                recoverable_pj => $rec, severity => 'MAJOR'
            };
            $n_low_eff++;
        } elsif ($g->{regs} < $min_regs && $eff < $min_eff) {
            push @violations, {
                type => 'REDUNDANT_GATE', object => $id, module => $g->{module},
                recoverable_pj => 0.00, severity => 'MINOR'
            };
            $n_red++;
        }

        if ($tog > $max_tog) {
            push @violations, {
                type => 'ENABLE_TOO_ACTIVE', object => $id, module => $g->{module},
                recoverable_pj => 0.00, severity => 'MAJOR'
            };
            $n_tog++;
        }
    }

    my $status = "PASS";
    if ($n_missing > 0) {
        $status = "FAIL";
    } elsif ($n_low_eff > 0 || $n_tog > 0 || $n_red > 0) {
        $status = "WARNING";
    }

    return {
        cfg => \%cfg, gates => \%gates, ungated => \%ungated,
        total_energy => $total_energy, total_regs => $total_regs,
        overall_eff => $overall_eff, violations => \@violations,
        n_missing => $n_missing, n_low_eff => $n_low_eff,
        n_tog => $n_tog, n_red => $n_red, status => $status,
        obj_energy => \%obj_energy, obj_eff => \%obj_eff
    };
}

my $pre  = analyze_dataset($pre_file);
my $post = analyze_dataset($post_file);

# Gates added and removed
my @added_gates;
for my $id (sort keys %{$post->{gates}}) {
    push @added_gates, $id unless exists $pre->{gates}{$id};
}

my @removed_gates;
for my $id (sort keys %{$pre->{gates}}) {
    push @removed_gates, $id unless exists $post->{gates}{$id};
}

my $gates_added_str   = @added_gates   ? join(",", @added_gates)   : "NONE";
my $gates_removed_str = @removed_gates ? join(",", @removed_gates) : "NONE";

# Parse fix_plan.txt and calculate accuracy
my @plan_items;
open(my $pfh, '<', $plan_file) or die "Cannot read $plan_file: $!\n";
while (my $line = <$pfh>) {
    chomp $line;
    next if $line =~ /^\s*$/;
    if ($line =~ /^FIX OBJECT=(\S+)\s+ACTION=(\S+)\s+MODULE=(\S+)\s+REGS=(\d+)\s+EXPECTED_ENERGY_PJ=([\d.]+)/) {
        push @plan_items, {
            object => $1, action => $2, module => $3, regs => $4 + 0, expected_energy => $5 + 0.0
        };
    }
}
close($pfh);

my $accurate_actions = 0;
for my $item (@plan_items) {
    my $achieved_energy = -1.0;
    if ($item->{action} eq 'INSERT_CLOCK_GATE') {
        # Match by registers and module in post-fix gates
        for my $gid (keys %{$post->{gates}}) {
            my $g = $post->{gates}{$gid};
            if ($g->{module} eq $item->{module} && $g->{regs} == $item->{regs}) {
                $achieved_energy = $post->{obj_energy}{$gid};
                last;
            }
        }
    } elsif ($item->{action} eq 'REMOVE_GATE') {
        # Regs moved to ungated in module
        for my $uid (keys %{$post->{ungated}}) {
            my $u = $post->{ungated}{$uid};
            if ($u->{module} eq $item->{module} && $u->{regs} == $item->{regs}) {
                $achieved_energy = $post->{obj_energy}{$uid};
                last;
            }
        }
        $achieved_energy = $item->{regs} * ($post->{cfg}{TOTAL_CYCLES} || 10000) * ($post->{cfg}{E_CLK_PJ_PER_REG_CYCLE} || 0.30)
            if $achieved_energy < 0;
    } else {
        # REFINE_ENABLE or REGISTER_ENABLE: direct object lookup
        if (exists $post->{obj_energy}{$item->{object}}) {
            $achieved_energy = $post->{obj_energy}{$item->{object}};
        }
    }

    if ($achieved_energy >= 0) {
        my $exp = $item->{expected_energy};
        my $diff = abs($achieved_energy - $exp);
        my $tol  = 0.05 * $exp;
        $accurate_actions++ if ($diff <= $tol || $diff < 0.01);
    }
}

my $plan_accuracy = (@plan_items > 0) ? ($accurate_actions / scalar(@plan_items)) * 100.0 : 100.0;

# Closure metrics
my $saving_pj      = $pre->{total_energy} - $post->{total_energy};
my $saving_percent = ($pre->{total_energy} > 0) ? ($saving_pj / $pre->{total_energy}) * 100.0 : 0.0;
my $target_saving  = $pre->{cfg}{TARGET_SAVING_PERCENT} || 15.0;

my $reg_conserved = ($pre->{total_regs} == $post->{total_regs}) ? "PASS" : "FAIL";

my $closure_status = "FAIL";
if ($post->{n_missing} == 0 &&
    $post->{n_low_eff} == 0 &&
    $post->{n_tog} == 0 &&
    $saving_percent >= $target_saving &&
    $reg_conserved eq 'PASS') {
    $closure_status = "PASS";
}

# Write submit_here/final_report.rpt
mkdir $out_dir unless -d $out_dir;
my $final_rpt = File::Spec->catfile($out_dir, "final_report.rpt");
open(my $out, '>', $final_rpt) or die "Cannot write to $final_rpt: $!\n";

print $out "=== BEFORE ===\n";
for my $id (sort keys %{$pre->{gates}}) {
    printf $out "GATE=%s REGS=%d EFFICIENCY_PERCENT=%.2f ENERGY_PJ=%.2f MODULE=%s\n",
        $id, $pre->{gates}{$id}{regs}, $pre->{obj_eff}{$id}, $pre->{obj_energy}{$id}, $pre->{gates}{$id}{module};
}
for my $name (sort keys %{$pre->{ungated}}) {
    printf $out "UNGATED=%s REGS=%d EFFICIENCY_PERCENT=0.00 ENERGY_PJ=%.2f MODULE=%s\n",
        $name, $pre->{ungated}{$name}{regs}, $pre->{obj_energy}{$name}, $pre->{ungated}{$name}{module};
}
printf $out "TOTAL_CLOCK_ENERGY_PJ=%.2f  OVERALL_EFFICIENCY_PERCENT=%.2f  TOTAL_REGISTERS=%d\n\n",
    $pre->{total_energy}, $pre->{overall_eff}, $pre->{total_regs};

print $out "=== DETECTED ISSUES ===\n";
for my $v (@{$pre->{violations}}) {
    printf $out "VIOLATION TYPE=%s OBJECT=%s MODULE=%s RECOVERABLE_PJ=%.2f SEVERITY=%s\n",
        $v->{type}, $v->{object}, $v->{module}, $v->{recoverable_pj}, $v->{severity};
}
print $out "\n";

print $out "=== CORRECTION / RECOMMENDATION ===\n";
my $fix_rpt_file = File::Spec->catfile($out_dir, "level4_fix_plan.rpt");
if (-e $fix_rpt_file) {
    open(my $ffh, '<', $fix_rpt_file);
    while (my $l = <$ffh>) {
        print $out $l if $l =~ /^FIX\s+/;
    }
    close($ffh);
}
print $out "\n";

print $out "=== AFTER ===\n";
for my $id (sort keys %{$post->{gates}}) {
    printf $out "GATE=%s REGS=%d EFFICIENCY_PERCENT=%.2f ENERGY_PJ=%.2f MODULE=%s\n",
        $id, $post->{gates}{$id}{regs}, $post->{obj_eff}{$id}, $post->{obj_energy}{$id}, $post->{gates}{$id}{module};
}
for my $name (sort keys %{$post->{ungated}}) {
    printf $out "UNGATED=%s REGS=%d EFFICIENCY_PERCENT=0.00 ENERGY_PJ=%.2f MODULE=%s\n",
        $name, $post->{ungated}{$name}{regs}, $post->{obj_energy}{$name}, $post->{ungated}{$name}{module};
}
printf $out "TOTAL_CLOCK_ENERGY_PJ=%.2f  OVERALL_EFFICIENCY_PERCENT=%.2f  TOTAL_REGISTERS=%d\n",
    $post->{total_energy}, $post->{overall_eff}, $post->{total_regs};
printf $out "GATES_ADDED=%s\n", $gates_added_str;
printf $out "GATES_REMOVED=%s\n\n", $gates_removed_str;

print $out "=== CLOSURE ===\n";
printf $out "ENERGY_BEFORE_PJ=%.2f  ENERGY_AFTER_PJ=%.2f\n", $pre->{total_energy}, $post->{total_energy};
printf $out "SAVING_PJ=%.2f  SAVING_PERCENT=%.2f\n", $saving_pj, $saving_percent;
printf $out "TARGET_SAVING_PERCENT=%.2f\n", $target_saving;
printf $out "OVERALL_EFFICIENCY_BEFORE=%.2f  OVERALL_EFFICIENCY_AFTER=%.2f\n", $pre->{overall_eff}, $post->{overall_eff};
printf $out "MISSING_GATE_BEFORE=%d  MISSING_GATE_AFTER=%d\n", $pre->{n_missing}, $post->{n_missing};
printf $out "LOW_EFFICIENCY_BEFORE=%d  LOW_EFFICIENCY_AFTER=%d\n", $pre->{n_low_eff}, $post->{n_low_eff};
printf $out "ENABLE_TOO_ACTIVE_BEFORE=%d  ENABLE_TOO_ACTIVE_AFTER=%d\n", $pre->{n_tog}, $post->{n_tog};
printf $out "REGISTERS_BEFORE=%d  REGISTERS_AFTER=%d\n", $pre->{total_regs}, $post->{total_regs};
printf $out "REGISTER_CONSERVATION=%s\n", $reg_conserved;
printf $out "PLAN_ACCURACY_PERCENT=%.2f\n", $plan_accuracy;
printf $out "BEFORE_STATUS=%s  AFTER_STATUS=%s\n", $pre->{status}, $post->{status};
printf $out "CLOSURE=%s\n", $closure_status;

close($out);

# Write submit_here/machine_summary.txt
my $summary_file = File::Spec->catfile($out_dir, "machine_summary.txt");
open(my $sout, '>', $summary_file) or die "Cannot write to $summary_file: $!\n";
printf $sout "BATCH=04\n";
printf $sout "ENERGY_BEFORE_PJ=%.2f\n", $pre->{total_energy};
printf $sout "ENERGY_AFTER_PJ=%.2f\n", $post->{total_energy};
printf $sout "SAVING_PJ=%.2f\n", $saving_pj;
printf $sout "SAVING_PERCENT=%.2f\n", $saving_percent;
printf $sout "REGISTERS_BEFORE=%d\n", $pre->{total_regs};
printf $sout "REGISTERS_AFTER=%d\n", $post->{total_regs};
printf $sout "REGISTER_CONSERVATION=%s\n", $reg_conserved;
printf $sout "PLAN_ACCURACY_PERCENT=%.2f\n", $plan_accuracy;
printf $sout "BEFORE_STATUS=%s\n", $pre->{status};
printf $sout "AFTER_STATUS=%s\n", $post->{status};
printf $sout "CLOSURE=%s\n", $closure_status;
close($sout);

print "Successfully generated $final_rpt and $summary_file\n";
