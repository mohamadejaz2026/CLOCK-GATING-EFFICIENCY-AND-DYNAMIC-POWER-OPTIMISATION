#!/usr/bin/env perl
use strict;
use warnings;
use File::Spec;

my $in_dir  = $ARGV[0] or die "Usage: $0 <inputs_dir> <output_dir>\n";
my $out_dir = $ARGV[1] or die "Usage: $0 <inputs_dir> <output_dir>\n";

my $rpt_file = File::Spec->catfile($in_dir, "reports", "pre_fix", "clock_gating.rpt");
die "Error: Input file '$rpt_file' not found!\n" unless (-e $rpt_file && -r $rpt_file);

my (%cfg, %gates, %ungated, %modules);

open(my $fh, '<', $rpt_file) or die "Cannot read $rpt_file: $!\n";
while (my $line = <$fh>) {
    chomp $line;
    next if $line =~ /^\s*(#|$)/;
    $line =~ s/^\s+//;
    $line =~ s/\s+$//;

    if ($line =~ /TOTAL_CYCLES\s+(\d+)/)                 { $cfg{TOTAL_CYCLES} = $1; }
    if ($line =~ /MIN_GATING_EFFICIENCY\s+([\d.]+)/)     { $cfg{MIN_GATING_EFFICIENCY} = $1; }
    if ($line =~ /E_CLK_PJ_PER_REG_CYCLE\s+([\d.]+)/)    { $cfg{E_CLK_PJ_PER_REG_CYCLE} = $1; }
    if ($line =~ /MIN_REGS_FOR_GATING\s+(\d+)/)          { $cfg{MIN_REGS_FOR_GATING} = $1; }
    if ($line =~ /MAX_ENABLE_TOGGLE_PERCENT\s+([\d.]+)/) { $cfg{MAX_ENABLE_TOGGLE_PERCENT} = $1; }
    if ($line =~ /TARGET_SAVING_PERCENT\s+([\d.]+)/)     { $cfg{TARGET_SAVING_PERCENT} = $1; }

    if ($line =~ /^GATE\s+(\S+)\s+ENABLE\s+(\S+)\s+REGS\s+(\d+)\s+DISABLED_CYCLES\s+(\d+)\s+ENABLE_TOGGLES\s+(\d+)\s+MODULE\s+(\S+)/) {
        $gates{$1} = {
            id => $1, enable => $2, regs => $3 + 0,
            disabled_cycles => $4 + 0, enable_toggles => $5 + 0, module => $6
        } unless exists $gates{$1};
    }

    if ($line =~ /^UNGATED_GROUP\s+(\S+)\s+REGS\s+(\d+)\s+IDLE_CYCLES\s+(\d+)\s+MODULE\s+(\S+)/) {
        $ungated{$1} = {
            name => $1, regs => $2 + 0, idle_cycles => $3 + 0, module => $4
        } unless exists $ungated{$1};
    }
}
close($fh);

my $tot_cyc  = $cfg{TOTAL_CYCLES} || 10000;
my $min_eff  = $cfg{MIN_GATING_EFFICIENCY} || 60.0;
my $e_clk    = $cfg{E_CLK_PJ_PER_REG_CYCLE} || 0.30;
my $min_regs = $cfg{MIN_REGS_FOR_GATING} || 8;
my $max_tog  = $cfg{MAX_ENABLE_TOGGLE_PERCENT} || 50.0;

my $target_disabled = $tot_cyc * $min_eff / 100.0;
my $total_disabled_reg_cycles = 0;
my $total_regs = 0;

for my $id (keys %gates) {
    my $g = $gates{$id};
    my $energy = $g->{regs} * ($tot_cyc - $g->{disabled_cycles}) * $e_clk;
    $total_disabled_reg_cycles += ($g->{regs} * $g->{disabled_cycles});
    $total_regs += $g->{regs};
    $modules{$g->{module}}{energy} += $energy;
    $modules{$g->{module}}{recoverable} += 0.0;
}

for my $name (keys %ungated) {
    my $u = $ungated{$name};
    my $energy = $u->{regs} * $tot_cyc * $e_clk;
    $total_regs += $u->{regs};
    $modules{$u->{module}}{energy} += $energy;
    $modules{$u->{module}}{recoverable} += 0.0;
}

my @opportunities;

# 1. Opportunities from UNGATED_GROUP
for my $name (keys %ungated) {
    my $u = $ungated{$name};
    my $idle_pct = ($u->{idle_cycles} / $tot_cyc) * 100.0;
    if ($u->{regs} >= $min_regs && $idle_pct >= $min_eff) {
        my $rec = $u->{regs} * $u->{idle_cycles} * $e_clk;
        push @opportunities, {
            object         => $name,
            type           => 'MISSING_GATE',
            module         => $u->{module},
            regs           => $u->{regs},
            recoverable_pj => $rec,
            reason         => sprintf("Ungated group with %d regs idle %.2f%% of cycles", $u->{regs}, $idle_pct)
        };
        $modules{$u->{module}}{recoverable} += $rec;
    }
}

# 2. Opportunities from GATES
for my $id (keys %gates) {
    my $g = $gates{$id};
    my $eff = ($g->{disabled_cycles} / $tot_cyc) * 100.0;
    my $tog = ($g->{enable_toggles} / $tot_cyc) * 100.0;

    if ($g->{regs} >= $min_regs && $eff < $min_eff) {
        my $rec = $g->{regs} * ($target_disabled - $g->{disabled_cycles}) * $e_clk;
        push @opportunities, {
            object         => $id,
            type           => 'LOW_EFFICIENCY',
            module         => $g->{module},
            regs           => $g->{regs},
            recoverable_pj => $rec,
            reason         => sprintf("Efficiency %.2f%% below target %.2f%%", $eff, $min_eff)
        };
        $modules{$g->{module}}{recoverable} += $rec;
    } elsif ($g->{regs} < $min_regs && $eff < $min_eff) {
        push @opportunities, {
            object         => $id,
            type           => 'REDUNDANT_GATE',
            module         => $g->{module},
            regs           => $g->{regs},
            recoverable_pj => 0.00,
            reason         => sprintf("Gate controls only %d regs (< %d)", $g->{regs}, $min_regs)
        };
    }

    if ($tog > $max_tog) {
        push @opportunities, {
            object         => $id,
            type           => 'ENABLE_TOO_ACTIVE',
            module         => $g->{module},
            regs           => $g->{regs},
            recoverable_pj => 0.00,
            reason         => sprintf("Enable toggle rate %.2f%% exceeds limit %.2f%%", $tog, $max_tog)
        };
    }
}

# Rank opportunities: RECOVERABLE desc, REGS desc, OBJECT asc
my @ranked = sort {
    $b->{recoverable_pj} <=> $a->{recoverable_pj}
    || $b->{regs} <=> $a->{regs}
    || $a->{object} cmp $b->{object}
} @opportunities;

# Find dominant module
my $dominant_module = "";
my $max_module_rec  = -1.0;
for my $m (sort keys %modules) {
    if ($modules{$m}{recoverable} > $max_module_rec) {
        $max_module_rec = $modules{$m}{recoverable};
        $dominant_module = $m;
    }
}

# Top 3 opportunities metrics
my $total_recoverable = 0.0;
my $top3_recoverable  = 0.0;
my $count = 0;

for my $op (@ranked) {
    $total_recoverable += $op->{recoverable_pj};
    if ($count < 3) {
        $top3_recoverable += $op->{recoverable_pj};
        $count++;
    }
}

my $top3_share = ($total_recoverable > 0) ? ($top3_recoverable / $total_recoverable) * 100.0 : 0.0;

# Projected efficiency
my $projected_disabled = $total_disabled_reg_cycles + ($total_recoverable / $e_clk);
my $projected_eff = ($total_regs > 0 && $tot_cyc > 0) ? ($projected_disabled / ($total_regs * $tot_cyc)) * 100.0 : 0.0;

mkdir $out_dir unless -d $out_dir;
my $out_file = File::Spec->catfile($out_dir, "level3_priority.rpt");
open(my $out, '>', $out_file) or die "Cannot write to $out_file: $!\n";

my $rank_idx = 1;
for my $op (@ranked) {
    printf $out "RANK=%d OBJECT=%s TYPE=%s MODULE=%s REGS=%d RECOVERABLE_PJ=%.2f REASON=%s\n",
        $rank_idx++, $op->{object}, $op->{type}, $op->{module}, $op->{regs}, $op->{recoverable_pj}, $op->{reason};
}
print $out "\n";

for my $m (sort keys %modules) {
    my $m_energy = $modules{$m}{energy} || 0.0;
    my $m_rec    = $modules{$m}{recoverable} || 0.0;
    my $m_pct    = ($m_energy > 0) ? ($m_rec / $m_energy) * 100.0 : 0.0;
    printf $out "MODULE=%s ENERGY_PJ=%.2f RECOVERABLE_PJ=%.2f RECOVERABLE_PERCENT=%.2f\n",
        $m, $m_energy, $m_rec, $m_pct;
}
print $out "\n";

printf $out "DOMINANT_MODULE=%s\n", $dominant_module;
printf $out "TOP3_RECOVERABLE_PJ=%.2f\n", $top3_recoverable;
printf $out "TOP3_SHARE_PERCENT=%.2f\n", $top3_share;
printf $out "PROJECTED_EFFICIENCY_PERCENT=%.2f\n", $projected_eff;
printf $out "RANKED_OPPORTUNITIES=%d\n", scalar(@ranked);

close($out);
print "Successfully generated $out_file\n";
