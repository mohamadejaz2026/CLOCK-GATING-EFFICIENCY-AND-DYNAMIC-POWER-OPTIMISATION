#!/usr/bin/env perl
use strict;
use warnings;
use File::Spec;

# 1. Accept directory arguments
my $in_dir  = $ARGV[0] or die "Usage: $0 <inputs_dir> <output_dir>\n";
my $out_dir = $ARGV[1] or die "Usage: $0 <inputs_dir> <output_dir>\n";

my $rpt_file = File::Spec->catfile($in_dir, "reports", "pre_fix", "clock_gating.rpt");
die "Error: Cannot open '$rpt_file'\n" unless (-e $rpt_file && -r $rpt_file);

my (%cfg, %gates, %ungated);

open(my $fh, '<', $rpt_file) or die "Cannot read $rpt_file: $!\n";
while (my $line = <$fh>) {
    chomp $line;
    next if $line =~ /^\s*(#|$)/; # Skip comments and blank lines
    $line =~ s/^\s+//;
    $line =~ s/\s+$//;

    # Parse Constants
    if ($line =~ /TOTAL_CYCLES\s+(\d+)/)                 { $cfg{TOTAL_CYCLES} = $1; }
    if ($line =~ /MIN_GATING_EFFICIENCY\s+([\d.]+)/)     { $cfg{MIN_GATING_EFFICIENCY} = $1; }
    if ($line =~ /E_CLK_PJ_PER_REG_CYCLE\s+([\d.]+)/)    { $cfg{E_CLK_PJ_PER_REG_CYCLE} = $1; }
    if ($line =~ /MIN_REGS_FOR_GATING\s+(\d+)/)          { $cfg{MIN_REGS_FOR_GATING} = $1; }
    if ($line =~ /MAX_ENABLE_TOGGLE_PERCENT\s+([\d.]+)/) { $cfg{MAX_ENABLE_TOGGLE_PERCENT} = $1; }
    if ($line =~ /TARGET_SAVING_PERCENT\s+([\d.]+)/)     { $cfg{TARGET_SAVING_PERCENT} = $1; }

    # Parse GATE records
    if ($line =~ /^GATE\s+(\S+)\s+ENABLE\s+(\S+)\s+REGS\s+(\d+)\s+DISABLED_CYCLES\s+(\d+)\s+ENABLE_TOGGLES\s+(\d+)\s+MODULE\s+(\S+)/) {
        $gates{$1} = {
            id              => $1,
            enable          => $2,
            regs            => $3 + 0,
            disabled_cycles => $4 + 0,
            enable_toggles  => $5 + 0,
            module          => $6
        } unless exists $gates{$1};
        next;
    }

    # Parse UNGATED_GROUP records
    if ($line =~ /^UNGATED_GROUP\s+(\S+)\s+REGS\s+(\d+)\s+IDLE_CYCLES\s+(\d+)\s+MODULE\s+(\S+)/) {
        $ungated{$1} = {
            name        => $1,
            regs        => $2 + 0,
            idle_cycles => $3 + 0,
            module      => $4
        } unless exists $ungated{$1};
        next;
    }
}
close($fh);

my $tot_cyc  = $cfg{TOTAL_CYCLES} || 1;
my $min_eff  = $cfg{MIN_GATING_EFFICIENCY} || 0.0;
my $e_clk    = $cfg{E_CLK_PJ_PER_REG_CYCLE} || 0.0;
my $min_regs = $cfg{MIN_REGS_FOR_GATING} || 0;
my $max_tog  = $cfg{MAX_ENABLE_TOGGLE_PERCENT} || 0.0;

my $target_disabled = $tot_cyc * $min_eff / 100.0;
my $total_clock_energy = 0.0;

# Calculate Baseline Total Clock Energy
for my $id (keys %gates) {
    my $g = $gates{$id};
    $total_clock_energy += $g->{regs} * ($tot_cyc - $g->{disabled_cycles}) * $e_clk;
}
for my $name (keys %ungated) {
    my $u = $ungated{$name};
    $total_clock_energy += $u->{regs} * $tot_cyc * $e_clk;
}

my @violations;

# 1. Check Ungated Groups for MISSING_GATE
for my $name (sort keys %ungated) {
    my $u = $ungated{$name};
    my $idle_pct = ($u->{idle_cycles} / $tot_cyc) * 100.0;
    if ($u->{regs} >= $min_regs && $idle_pct >= $min_eff) {
        my $rec = $u->{regs} * $u->{idle_cycles} * $e_clk;
        push @violations, {
            type           => 'MISSING_GATE',
            object         => $name,
            module         => $u->{module},
            measured       => $idle_pct,
            limit          => $min_eff,
            recoverable_pj => $rec,
            severity       => 'CRITICAL'
        };
    }
}

# 2. Check Gates for LOW_EFFICIENCY, REDUNDANT_GATE, and ENABLE_TOO_ACTIVE
for my $id (sort keys %gates) {
    my $g = $gates{$id};
    my $eff = ($g->{disabled_cycles} / $tot_cyc) * 100.0;
    my $tog_pct = ($g->{enable_toggles} / $tot_cyc) * 100.0;

    # LOW_EFFICIENCY vs REDUNDANT_GATE
    if ($g->{regs} >= $min_regs && $eff < $min_eff) {
        my $rec = $g->{regs} * ($target_disabled - $g->{disabled_cycles}) * $e_clk;
        push @violations, {
            type           => 'LOW_EFFICIENCY',
            object         => $id,
            module         => $g->{module},
            measured       => $eff,
            limit          => $min_eff,
            recoverable_pj => $rec,
            severity       => 'MAJOR'
        };
    } elsif ($g->{regs} < $min_regs && $eff < $min_eff) {
        push @violations, {
            type           => 'REDUNDANT_GATE',
            object         => $id,
            module         => $g->{module},
            measured       => $eff,
            limit          => $min_eff,
            recoverable_pj => 0.00,
            severity       => 'MINOR'
        };
    }

    # ENABLE_TOO_ACTIVE
    if ($tog_pct > $max_tog) {
        push @violations, {
            type           => 'ENABLE_TOO_ACTIVE',
            object         => $id,
            module         => $g->{module},
            measured       => $tog_pct,
            limit          => $max_tog,
            recoverable_pj => 0.00,
            severity       => 'MAJOR'
        };
    }
}

my ($crit, $maj, $min, $wasted_pj) = (0, 0, 0, 0.0);
for my $v (@violations) {
    $crit++ if $v->{severity} eq 'CRITICAL';
    $maj++  if $v->{severity} eq 'MAJOR';
    $min++  if $v->{severity} eq 'MINOR';
    $wasted_pj += $v->{recoverable_pj};
}

my $wasted_pct = ($total_clock_energy > 0) ? ($wasted_pj / $total_clock_energy) * 100.0 : 0.0;

my $baseline_status = "PASS";
if ($crit > 0) {
    $baseline_status = "FAIL";
} elsif ($maj > 0 || $min > 0) {
    $baseline_status = "WARNING";
}

# Write submit_here/level2_violations.rpt
mkdir $out_dir unless -d $out_dir;
my $out_file = File::Spec->catfile($out_dir, "level2_violations.rpt");
open(my $out, '>', $out_file) or die "Cannot write to $out_file: $!\n";

for my $v (@violations) {
    printf $out "VIOLATION TYPE=%s OBJECT=%s MODULE=%s MEASURED=%.2f LIMIT=%.2f RECOVERABLE_PJ=%.2f SEVERITY=%s\n",
        $v->{type}, $v->{object}, $v->{module}, $v->{measured}, $v->{limit}, $v->{recoverable_pj}, $v->{severity};
}
print $out "\n";

printf $out "TOTAL_VIOLATIONS=%d\n", scalar(@violations);
printf $out "CRITICAL_COUNT=%d  MAJOR_COUNT=%d  MINOR_COUNT=%d\n", $crit, $maj, $min;
printf $out "WASTED_ENERGY_PJ=%.2f\n", $wasted_pj;
printf $out "WASTED_ENERGY_PERCENT=%.2f\n", $wasted_pct;
printf $out "BASELINE_STATUS=%s\n", $baseline_status;

close($out);
print "Successfully generated $out_file\n";
