#!/usr/bin/env perl
use strict;
use warnings;
use File::Spec;

my $in_dir  = $ARGV[0] or die "Usage: $0 <inputs_dir> <output_dir>\n";
my $out_dir = $ARGV[1] or die "Usage: $0 <inputs_dir> <output_dir>\n";

my $rpt_file = File::Spec->catfile($in_dir, "reports", "pre_fix", "clock_gating.rpt");
die "Error: Input file '$rpt_file' not found!\n" unless (-e $rpt_file && -r $rpt_file);

my (%cfg, %gates, %ungated);

open(my $fh, '<', $rpt_file) or die "Cannot read $rpt_file: $!\n";
while (my $line = <$fh>) {
    chomp $line;
    next if $line =~ /^\s*(#|$)/;
    $line =~ s/^\s+//;
    $line =~ s/\s+$//;

    if ($line =~ /TOTAL_CYCLES\s+(\d+)/)                 { $cfg{TOTAL_CYCLES} = $1; }
    if ($line =~ /MIN_GATING_EFFICIENCY\s+([\d.]+)/)     { $cfg{MIN_GATING_EFFICIENCY} = $1; }
    if ($line =~ /E_CLK_PJ_PER_REG_CYCLE\s+([\d.]+)/)    { $cfg{E_CLK_PJ_PER_REG_CYCLE} = $1; }
    if ($line =~ /MIN_REGS_FOR_GATING\s+(\d+)/)          { $cfg{MIN_REGS_FOR_GATING} = $1; }
    if ($line =~ /MAX_ENABLE_TOGGLE_PERCENT\s+([\d.]+)/) { $cfg{MAX_ENABLE_TOGGLE_PERCENT} = $1; }
    if ($line =~ /TARGET_SAVING_PERCENT\s+([\d.]+)/)     { $cfg{TARGET_SAVING_PERCENT} = $1; }

    if ($line =~ /^GATE\s+(\S+)\s+ENABLE\s+(\S+)\s+REGS\s+(\d+)\s+DISABLED_CYCLES\s+(\d+)\s+ENABLE_TOGGLES\s+(\d+)\s+MODULE\s+(\S+)/) {
        $gates{$1} = {
            id              => $1,
            enable          => $2,
            regs            => $3 + 0,
            disabled_cycles => $4 + 0,
            enable_toggles  => $5 + 0,
            module          => $6
        } unless exists $gates{$1};
    }

    if ($line =~ /^UNGATED_GROUP\s+(\S+)\s+REGS\s+(\d+)\s+IDLE_CYCLES\s+(\d+)\s+MODULE\s+(\S+)/) {
        $ungated{$1} = {
            name        => $1,
            regs        => $2 + 0,
            idle_cycles => $3 + 0,
            module      => $4
        } unless exists $ungated{$1};
    }
}
close($fh);

my $tot_cyc  = $cfg{TOTAL_CYCLES} || 10000;
my $min_eff  = $cfg{MIN_GATING_EFFICIENCY} || 60.0;
my $e_clk    = $cfg{E_CLK_PJ_PER_REG_CYCLE} || 0.30;
my $min_regs = $cfg{MIN_REGS_FOR_GATING} || 8;
my $max_tog  = $cfg{MAX_ENABLE_TOGGLE_PERCENT} || 50.0;
my $tgt_sav  = $cfg{TARGET_SAVING_PERCENT} || 15.0;

my $target_disabled = $tot_cyc * $min_eff / 100.0;
my $total_before_energy = 0.0;
my %current_energy;

for my $id (keys %gates) {
    my $g = $gates{$id};
    my $e = $g->{regs} * ($tot_cyc - $g->{disabled_cycles}) * $e_clk;
    $current_energy{$id} = $e;
    $total_before_energy += $e;
}
for my $name (keys %ungated) {
    my $u = $ungated{$name};
    my $e = $u->{regs} * $tot_cyc * $e_clk;
    $current_energy{$name} = $e;
    $total_before_energy += $e;
}

my @opportunities;

# 1. MISSING_GATE -> INSERT_CLOCK_GATE
for my $name (keys %ungated) {
    my $u = $ungated{$name};
    my $idle_pct = ($u->{idle_cycles} / $tot_cyc) * 100.0;
    if ($u->{regs} >= $min_regs && $idle_pct >= $min_eff) {
        my $rec   = $u->{regs} * $u->{idle_cycles} * $e_clk;
        my $exp_e = $u->{regs} * ($tot_cyc - $u->{idle_cycles}) * $e_clk;
        push @opportunities, {
            object         => $name,
            action         => 'INSERT_CLOCK_GATE',
            module         => $u->{module},
            regs           => $u->{regs},
            before_energy  => $current_energy{$name},
            exp_energy     => $exp_e,
            saving_pj      => $rec,
            recoverable_pj => $rec,
            reason         => sprintf("Ungated group with %d regs idle %.2f%% of cycles", $u->{regs}, $idle_pct)
        };
    }
}

# 2. Gate Issues
for my $id (keys %gates) {
    my $g = $gates{$id};
    my $eff = ($g->{disabled_cycles} / $tot_cyc) * 100.0;
    my $tog = ($g->{enable_toggles} / $tot_cyc) * 100.0;

    if ($g->{regs} >= $min_regs && $eff < $min_eff) {
        my $rec   = $g->{regs} * ($target_disabled - $g->{disabled_cycles}) * $e_clk;
        my $exp_e = $g->{regs} * ($tot_cyc - $target_disabled) * $e_clk;
        push @opportunities, {
            object         => $id,
            action         => 'REFINE_ENABLE',
            module         => $g->{module},
            regs           => $g->{regs},
            before_energy  => $current_energy{$id},
            exp_energy     => $exp_e,
            saving_pj      => $rec,
            recoverable_pj => $rec,
            reason         => sprintf("Efficiency %.2f%% below target %.2f%%", $eff, $min_eff)
        };
    } elsif ($g->{regs} < $min_regs && $eff < $min_eff) {
        my $exp_e   = $g->{regs} * $tot_cyc * $e_clk;
        my $penalty = $current_energy{$id} - $exp_e; # negative saving
        push @opportunities, {
            object         => $id,
            action         => 'REMOVE_GATE',
            module         => $g->{module},
            regs           => $g->{regs},
            before_energy  => $current_energy{$id},
            exp_energy     => $exp_e,
            saving_pj      => $penalty,
            recoverable_pj => 0.00,
            reason         => sprintf("Gate controls only %d regs (< %d)", $g->{regs}, $min_regs)
        };
    }

    if ($tog > $max_tog) {
        push @opportunities, {
            object         => $id,
            action         => 'REGISTER_ENABLE',
            module         => $g->{module},
            regs           => $g->{regs},
            before_energy  => $current_energy{$id},
            exp_energy     => $current_energy{$id},
            saving_pj      => 0.00,
            recoverable_pj => 0.00,
            reason         => sprintf("Enable toggle rate %.2f%% exceeds limit %.2f%%", $tog, $max_tog)
        };
    }
}

# Order fixes by Level-3 ranking: RECOVERABLE desc, REGS desc, OBJECT asc
my @fixes = sort {
    $b->{recoverable_pj} <=> $a->{recoverable_pj}
    || $b->{regs} <=> $a->{regs}
    || $a->{object} cmp $b->{object}
} @opportunities;

my ($n_ins, $n_ref, $n_reg, $n_rem) = (0, 0, 0, 0);
my %final_expected_energy = %current_energy;

for my $f (@fixes) {
    if ($f->{action} eq 'INSERT_CLOCK_GATE') { $n_ins++; $final_expected_energy{$f->{object}} = $f->{exp_energy}; }
    if ($f->{action} eq 'REFINE_ENABLE')     { $n_ref++; $final_expected_energy{$f->{object}} = $f->{exp_energy}; }
    if ($f->{action} eq 'REGISTER_ENABLE')   { $n_reg++; }
    if ($f->{action} eq 'REMOVE_GATE')       { $n_rem++; $final_expected_energy{$f->{object}} = $f->{exp_energy}; }
}

my $expected_total_energy = 0.0;
for my $obj (keys %final_expected_energy) {
    $expected_total_energy += $final_expected_energy{$obj};
}

my $exp_saving_pj  = $total_before_energy - $expected_total_energy;
my $exp_saving_pct = ($total_before_energy > 0) ? ($exp_saving_pj / $total_before_energy) * 100.0 : 0.0;
my $plan_meets     = ($exp_saving_pct >= $tgt_sav) ? "YES" : "NO";

mkdir $out_dir unless -d $out_dir;
my $out_file = File::Spec->catfile($out_dir, "level4_fix_plan.rpt");
my $txt_file = File::Spec->catfile($out_dir, "fix_plan.txt");

open(my $out, '>', $out_file) or die "Cannot write to $out_file: $!\n";
for my $f (@fixes) {
    printf $out "FIX OBJECT=%s ACTION=%s MODULE=%s REGS=%d BEFORE_ENERGY_PJ=%.2f EXPECTED_ENERGY_PJ=%.2f SAVING_PJ=%.2f REASON=%s\n",
        $f->{object}, $f->{action}, $f->{module}, $f->{regs}, $f->{before_energy}, $f->{exp_energy}, $f->{saving_pj}, $f->{reason};
}
print $out "\n";

printf $out "TOTAL_ACTIONS=%d\n", scalar(@fixes);
printf $out "GATES_TO_INSERT=%d  ENABLES_TO_REFINE=%d\n", $n_ins, $n_ref;
printf $out "ENABLES_TO_REGISTER=%d  GATES_TO_REMOVE=%d\n", $n_reg, $n_rem;
printf $out "ENERGY_BEFORE_PJ=%.2f\n", $total_before_energy;
printf $out "EXPECTED_ENERGY_PJ=%.2f\n", $expected_total_energy;
printf $out "EXPECTED_SAVING_PERCENT=%.2f\n", $exp_saving_pct;
printf $out "TARGET_SAVING_PERCENT=%.2f\n", $tgt_sav;
printf $out "PLAN_MEETS_TARGET=%s\n", $plan_meets;
close($out);

open(my $tfh, '>', $txt_file) or die "Cannot write to $txt_file: $!\n";
for my $f (@fixes) {
    printf $tfh "FIX OBJECT=%s ACTION=%s MODULE=%s REGS=%d EXPECTED_ENERGY_PJ=%.2f\n",
        $f->{object}, $f->{action}, $f->{module}, $f->{regs}, $f->{exp_energy};
}
close($tfh);

print "Successfully generated $out_file and $txt_file\n";
