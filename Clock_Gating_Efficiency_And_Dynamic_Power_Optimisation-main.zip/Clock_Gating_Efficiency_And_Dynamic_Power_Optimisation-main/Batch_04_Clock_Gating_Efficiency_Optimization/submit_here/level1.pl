#!/usr/bin/env perl
use strict;
use warnings;
use File::Spec;

my $in_dir  = $ARGV[0] or die "Usage: $0 <inputs_dir> <output_dir>\n";
my $out_dir = $ARGV[1] or die "Usage: $0 <inputs_dir> <output_dir>\n";

my $rpt_file = File::Spec->catfile($in_dir, "reports", "pre_fix", "clock_gating.rpt");
die "Error: Cannot read '$rpt_file'\n" unless (-e $rpt_file && -r $rpt_file);

my (%cfg, %gates, %ungated, %modules);
my $duplicate_records = 0;
my $skipped_records   = 0;

open(my $fh, '<', $rpt_file) or die "Cannot read $rpt_file: $!\n";

while (my $line = <$fh>) {
    chomp $line;
    next if $line =~ /^\s*(#|$)/;
    $line =~ s/^\s+//;
    $line =~ s/\s+$//;

    # Parse Constants (Handles 1 or 2 key-value pairs per line)
    if ($line =~ /TOTAL_CYCLES\s+(\d+)/)                 { $cfg{TOTAL_CYCLES} = $1; }
    if ($line =~ /MIN_GATING_EFFICIENCY\s+([\d.]+)/)     { $cfg{MIN_GATING_EFFICIENCY} = $1; }
    if ($line =~ /E_CLK_PJ_PER_REG_CYCLE\s+([\d.]+)/)    { $cfg{E_CLK_PJ_PER_REG_CYCLE} = $1; }
    if ($line =~ /MIN_REGS_FOR_GATING\s+(\d+)/)          { $cfg{MIN_REGS_FOR_GATING} = $1; }
    if ($line =~ /MAX_ENABLE_TOGGLE_PERCENT\s+([\d.]+)/) { $cfg{MAX_ENABLE_TOGGLE_PERCENT} = $1; }
    if ($line =~ /TARGET_SAVING_PERCENT\s+([\d.]+)/)     { $cfg{TARGET_SAVING_PERCENT} = $1; }

    # Parse GATE records
    if ($line =~ /^GATE\s+(\S+)\s+ENABLE\s+(\S+)\s+REGS\s+(\d+)\s+DISABLED_CYCLES\s+(\d+)\s+ENABLE_TOGGLES\s+(\d+)\s+MODULE\s+(\S+)/) {
        my ($id, $en, $regs, $dis, $tog, $mod) = ($1, $2, $3, $4, $5, $6);
        if (exists $gates{$id}) {
            $duplicate_records++;
        } else {
            $gates{$id} = {
                id => $id, enable => $en, regs => $regs + 0,
                disabled_cycles => $dis + 0, enable_toggles => $tog + 0, module => $mod
            };
        }
        next;
    }

    # Parse UNGATED_GROUP records
    if ($line =~ /^UNGATED_GROUP\s+(\S+)\s+REGS\s+(\d+)\s+IDLE_CYCLES\s+(\d+)\s+MODULE\s+(\S+)/) {
        my ($name, $regs, $idle, $mod) = ($1, $2, $3, $4);
        if (exists $ungated{$name}) {
            $duplicate_records++;
        } else {
            $ungated{$name} = {
                name => $name, regs => $regs + 0,
                idle_cycles => $idle + 0, module => $mod
            };
        }
        next;
    }

    # Mark unexpected records as skipped
    unless ($line =~ /(TOTAL_CYCLES|MIN_GATING_EFFICIENCY|E_CLK_PJ_PER_REG_CYCLE|MIN_REGS_FOR_GATING|MAX_ENABLE_TOGGLE_PERCENT|TARGET_SAVING_PERCENT)/) {
        $skipped_records++;
    }
}
close($fh);

my $input_status = ($duplicate_records == 0 && $skipped_records == 0) ? "PASS" : "FAIL";
my $tot_cyc      = $cfg{TOTAL_CYCLES} || 1;
my $e_clk        = $cfg{E_CLK_PJ_PER_REG_CYCLE} || 0.0;

my $gated_registers           = 0;
my $total_disabled_reg_cycles = 0;
my $total_clock_energy        = 0.0;

# Process Gates
for my $id (sort keys %gates) {
    my $g = $gates{$id};
    $g->{efficiency}    = ($g->{disabled_cycles} / $tot_cyc) * 100.0;
    $g->{active_cycles} = $tot_cyc - $g->{disabled_cycles};
    $g->{energy_pj}     = $g->{regs} * $g->{active_cycles} * $e_clk;

    $gated_registers           += $g->{regs};
    $total_disabled_reg_cycles += ($g->{regs} * $g->{disabled_cycles});
    $total_clock_energy        += $g->{energy_pj};

    my $m = $g->{module};
    $modules{$m}{regs}    += $g->{regs};
    $modules{$m}{gated}   += $g->{regs};
    $modules{$m}{ungated} += 0;
    $modules{$m}{energy}  += $g->{energy_pj};
}

# Process Ungated groups
my $ungated_registers = 0;
for my $name (sort keys %ungated) {
    my $u = $ungated{$name};
    $u->{idle_percent} = ($u->{idle_cycles} / $tot_cyc) * 100.0;
    $u->{energy_pj}    = $u->{regs} * $tot_cyc * $e_clk;

    $ungated_registers  += $u->{regs};
    $total_clock_energy += $u->{energy_pj};

    my $m = $u->{module};
    $modules{$m}{regs}    += $u->{regs};
    $modules{$m}{gated}   += 0;
    $modules{$m}{ungated} += $u->{regs};
    $modules{$m}{energy}  += $u->{energy_pj};
}

my $total_registers = $gated_registers + $ungated_registers;
my $denom           = $total_registers * $tot_cyc;
my $overall_eff     = ($denom > 0) ? ($total_disabled_reg_cycles / $denom) * 100.0 : 0.0;

# Write submit_here/level1_baseline.rpt
mkdir $out_dir unless -d $out_dir;
my $out_file = File::Spec->catfile($out_dir, "level1_baseline.rpt");
open(my $out, '>', $out_file) or die "Cannot write to $out_file: $!\n";

print $out "BATCH=04\n";
print $out "INPUT_STATUS=$input_status\n";
printf $out "TOTAL_CYCLES=%d\n", $tot_cyc;
printf $out "E_CLK_PJ_PER_REG_CYCLE=%.2f\n", $e_clk;
printf $out "GATES=%d\n", scalar(keys %gates);
printf $out "UNGATED_GROUPS=%d\n", scalar(keys %ungated);
printf $out "TOTAL_REGISTERS=%d\n", $total_registers;
printf $out "GATED_REGISTERS=%d\n", $gated_registers;
printf $out "UNGATED_REGISTERS=%d\n", $ungated_registers;
printf $out "TOTAL_CLOCK_ENERGY_PJ=%.2f\n", $total_clock_energy;
printf $out "OVERALL_EFFICIENCY_PERCENT=%.2f\n", $overall_eff;
printf $out "DUPLICATE_RECORDS=%d\n", $duplicate_records;
printf $out "SKIPPED_RECORDS=%d\n\n", $skipped_records;

for my $id (sort keys %gates) {
    my $g = $gates{$id};
    printf $out "GATE=%s ENABLE=%s REGS=%d EFFICIENCY_PERCENT=%.2f ACTIVE_CYCLES=%d ENERGY_PJ=%.2f MODULE=%s\n",
        $g->{id}, $g->{enable}, $g->{regs}, $g->{efficiency}, $g->{active_cycles}, $g->{energy_pj}, $g->{module};
}
print $out "\n";

for my $name (sort keys %ungated) {
    my $u = $ungated{$name};
    printf $out "UNGATED=%s REGS=%d IDLE_PERCENT=%.2f ENERGY_PJ=%.2f MODULE=%s\n",
        $u->{name}, $u->{regs}, $u->{idle_percent}, $u->{energy_pj}, $u->{module};
}
print $out "\n";

for my $m (sort keys %modules) {
    my $mod = $modules{$m};
    printf $out "MODULE=%s REGS=%d GATED=%d UNGATED=%d ENERGY_PJ=%.2f\n",
        $m, $mod->{regs}, $mod->{gated}, $mod->{ungated}, $mod->{energy};
}

close($out);
print "Successfully generated $out_file\n";
